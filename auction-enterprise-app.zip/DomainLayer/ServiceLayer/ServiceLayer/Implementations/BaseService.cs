﻿// <copyright file="BaseService.cs" company="Transilvania University of Brașov">
// Copyright (c) Curta Andrei. All rights reserved.
// </copyright>

namespace ServiceLayer.Implementations
{
    using System.Collections.Generic;
    using System.Linq;
    using DataMapper.Repository;
    using FluentValidation;
    using Microsoft.Extensions.Logging;
    using ServiceLayer.Interfaces;

    /// <summary>
    /// Base service to provide common functionality.
    /// </summary>
    /// <typeparam name="TE">The Entity.</typeparam>
    /// <typeparam name="TS">The Service that corresponds to the Entity.</typeparam>
    /// <typeparam name="TV">The Validator that coresponds to the Entity.</typeparam>
    public abstract class BaseService<TE, TS, TV> : IService<TE>
        where TV : AbstractValidator<TE>
        where TS : IRepository<TE>
    {
        /// <summary>
        /// The service that corresponds to the entity managed by this service.
        /// </summary>
        protected readonly TS service;

        /// <summary>
        /// The validator that corresponds to the entity managed by this service.
        /// </summary>
        protected readonly TV validator;

        /// <summary>
        /// The logger.
        /// </summary>
        protected readonly ILogger logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseService{TE, TS, TV}"/> class.
        /// </summary>
        /// <param name="service">The service that corresponds to the entity managed by this service.</param>
        /// <param name="validator">The validator that corresponds to the entity managed by this service.</param>
        /// <param name="logger">The logger.</param>
        protected BaseService(TS service, TV validator, ILogger logger = null)
        {
            this.service = service;
            this.validator = validator;
            this.logger = logger;
        }

        /// <inheritdoc/>
        public virtual void Add(TE entity)
        {
            this.validator.ValidateAndThrow(entity);

            this.service.Insert(entity);
        }

        /// <inheritdoc/>
        public virtual void Delete(TE entity)
        {
            this.service.Delete(entity);
        }

        // /// <inheritdoc/>
        // public virtual void Delete(object id)
        // {
        //     this.service.Delete(id);
        // }

        /// <inheritdoc/>
        public virtual TE GetById(long id)
        {
            return this.service.GetByID(id);
        }

        /// <inheritdoc/>
        public virtual IList<TE> List()
        {
            return this.service.Get().ToList();
        }

        /// <inheritdoc/>
        public virtual void Update(TE entity)
        {
            this.service.Update(entity);
        }
    }
}